class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        val ageInput = findViewById<EditText>(R.id.ageInput)
        val checkButton = findViewById<Button>(R.id.checkButton)
        val resultText = findViewById<TextView>(R.id.resultText)

        checkButton.setOnClickListener {
            val name = nameInput.text.toString()
            val age = ageInput.text.toString().toIntOrNull()

            val message = when {
                name.isEmpty() || age == null -> "Vui lòng nhập đầy đủ tên và tuổi"
                age > 65 -> "$name là Người già"
                age in 6..65 -> "$name là Người lớn"
                age in 2..5 -> "$name là Trẻ em"
                else -> "$name là Em bé"
            }

            resultText.text = message
        }
    }
}
