# Jetpack Compose UI Components Demo
Ứng dụng Android này là một bộ sưu tập các ví dụ về các thành phần giao diện người dùng (UI) cơ bản được xây dựng bằng Jetpack Compose. Mỗi thành phần được trình bày trong một Activity riêng biệt, giúp người học dễ dàng hiểu và áp dụng trong các dự án thực tế.

## Tính năng nổi bật
- Hiển thị: Text, Image, Button
- Nhập liệu: TextField, PasswordField
- Bố cục: Column, Row, Box
